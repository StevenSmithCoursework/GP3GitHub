/// @ref core
/// @file glm/matrix.hpp

#pragma once

#include "detail/func_matrix.hpp"
